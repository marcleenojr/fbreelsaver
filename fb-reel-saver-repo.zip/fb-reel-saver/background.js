const SAVEFROM = "https://en1.savefrom.net/9-how-to-download-facebook-video-8GJ.html";

const safe = (s) => String(s || "").replace(/[\\/:*?"<>|]+/g, "").replace(/\s+/g, " ").trim();
function makeName(i) {
  let n = (safe(i.page).slice(0, 50) + "_" + safe(i.id) + "_" + safe(i.date)).replace(/^_+|_+$/g, "");
  if (!n) n = "facebook_video";
  return n + ".mp4";
}

function markDownloaded(info) {
  if (!info || !info.id) return;
  chrome.storage.local.get("downloaded", (d) => {
    const all = d.downloaded || {};
    all[info.id] = { page: info.page, caption: info.caption, url: info.url, date: info.date };
    chrome.storage.local.set({ downloaded: all });
  });
}

// Listahan ng mga download na binabantayan (naka-store para hindi mawala kapag natulog ang service worker)
const getWatch = () => new Promise((r) => chrome.storage.local.get("dlWatch", (d) => r(d.dlWatch || {})));
const setWatch = (w) => chrome.storage.local.set({ dlWatch: w });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;

  if (msg.type === "MARK_DOWNLOADED") {
    markDownloaded(msg.info);
    return;
  }

  if (msg.type === "OPEN_SAVEFROM") {
    const i = msg.info || {};
    chrome.storage.local.set(
      { pendingUrl: msg.url, pendingInfo: i, pendingAt: Date.now(), downloadName: makeName(i), downloadNameAt: Date.now() },
      () => chrome.tabs.create({ url: SAVEFROM })
    );
    return;
  }

  // Direktang download gamit ang link na nakuha sa savefrom (may sarili nating pangalan ng file)
  if (msg.type === "DO_DOWNLOAD") {
    const info = msg.info || {};
    chrome.downloads.download({ url: msg.url, filename: makeName(info), conflictAction: "uniquify" }, async (id) => {
      if (chrome.runtime.lastError || id === undefined) {
        sendResponse({ ok: false, error: chrome.runtime.lastError && chrome.runtime.lastError.message });
        return;
      }
      const w = await getWatch();
      w[id] = { tabId: sender.tab && sender.tab.id, info };
      await setWatch(w);
      sendResponse({ ok: true, id });
    });
    return true; // async na sagot
  }
});

// Markahan lang bilang "na-download" kapag TAPOS na talaga ang file
chrome.downloads.onChanged.addListener(async (delta) => {
  if (!delta.state) return;
  const w = await getWatch();
  const item = w[delta.id];
  if (!item) return;
  delete w[delta.id];
  await setWatch(w);
  if (delta.state.current === "complete") {
    markDownloaded(item.info);
    if (item.tabId != null) {
      chrome.tabs.sendMessage(item.tabId, { type: "DL_DONE" }).catch(() => {});
      setTimeout(() => chrome.tabs.remove(item.tabId).catch(() => {}), 1500);
    }
  } else if (delta.state.current === "interrupted" && item.tabId != null) {
    chrome.tabs.sendMessage(item.tabId, { type: "DL_FAILED" }).catch(() => {});
  }
});

// Para sa "fallback na click": palitan ang pangalan ng file para malaman kung anong video ito
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  chrome.storage.local.get(["downloadName", "downloadNameAt"], (d) => {
    const recent = d.downloadName && Date.now() - (d.downloadNameAt || 0) < 5 * 60 * 1000;
    const isVideo = /video/i.test(item.mime || "") || /\.mp4$/i.test(item.filename || "");
    if (recent && isVideo) {
      chrome.storage.local.remove(["downloadName", "downloadNameAt"]);
      suggest({ filename: d.downloadName, conflictAction: "uniquify" });
    } else suggest();
  });
  return true;
});
