// Awtomatikong pagpuno at pag-download sa savefrom.net
// Mga selector na nakumpirma sa view-source: #sf_url (input), #sf_submit (button), #sf_result (lalagyan ng resulta)
(async () => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const { pendingUrl, pendingAt, pendingInfo } = await chrome.storage.local.get(["pendingUrl", "pendingAt", "pendingInfo"]);
  if (!pendingUrl || Date.now() - (pendingAt || 0) > 2 * 60 * 1000) return;
  await chrome.storage.local.remove(["pendingUrl", "pendingAt", "pendingInfo"]);
  const i = pendingInfo || {};

  // Banner na nagsasabi kung anong video at ano ang status
  const bar = document.createElement("div");
  bar.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;background:#16a34a;color:#fff;padding:10px 16px;font:14px sans-serif;text-align:center";
  document.body.appendChild(bar);
  const label = (i.page || "Facebook") + " • " + (i.caption || "(walang caption)") + " • ID " + (i.id || "?");
  const say = (t, bg) => { bar.textContent = t + "  —  " + label; if (bg) bar.style.background = bg; };
  say("Inihahanda ang download");

  // 1) Hintayin ang form
  let input = null, submit = null;
  for (let n = 0; n < 40 && !(input && submit); n++) {
    input = document.querySelector("#sf_url");
    submit = document.querySelector("#sf_submit");
    if (!(input && submit)) await sleep(250);
  }
  if (!input || !submit) return say("Hindi nahanap ang input box ng savefrom. Baka nagbago ang site.", "#b91c1c");

  // 2) Ilagay ang link at i-click ang Download
  const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
  setter.call(input, pendingUrl);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  await sleep(300);
  say("Hinahanap ang video");
  submit.click();

  // 3) Hintayin ang resulta sa #sf_result
  const txt = (e) => ((e.textContent || "") + " " + (e.getAttribute("title") || "") + " " + (e.getAttribute("data-quality") || "") + " " + (e.getAttribute("download") || "")).toLowerCase();
  const hrefOf = (a) => {
    let u = a.getAttribute("href") || "";
    if (!/^https?:/i.test(u)) u = a.getAttribute("data-copy") || "";
    return /^https?:/i.test(u) ? u : "";
  };
  function collectLinks(res) {
    let links = [...res.querySelectorAll("a.link-download, a[download]")];
    if (!links.length) {
      links = [...res.querySelectorAll('a[href^="http"]')].filter((a) => /download/i.test(a.textContent) || /googlevideo|fbcdn|video/i.test(a.href));
    }
    return links.filter((a) => a.getAttribute("href") || a.getAttribute("data-copy"));
  }
  function score(a) {
    const box = a.closest("li, .def-btn-box, .drop-down-box, div");
    const ctx = txt(a) + " " + (box ? txt(box) : "");
    let s = 0;
    if (/720/.test(ctx)) s += 10;
    if (/mp4/.test(ctx)) s += 3;
    if (/\bhd\b/.test(ctx)) s += 1;
    if (/audio|mp3|m4a|webm/.test(ctx)) s -= 5;
    if (a.offsetParent) s += 2;
    return s;
  }
  const qualityOf = (a) => { const m = (txt(a) + " " + (a.closest("li, div") ? txt(a.closest("li, div")) : "")).match(/(\d{3,4})p/); return m ? m[1] + "p" : "default"; };

  let chosen = null, fellBack = false;
  const started = Date.now();
  let firstSeen = 0;
  while (Date.now() - started < 90000) {
    await sleep(600);
    const res = document.querySelector("#sf_result");
    const links = res ? collectLinks(res) : [];
    if (links.length) {
      if (!firstSeen) firstSeen = Date.now();
      if (Date.now() - firstSeen < 1500) continue; // hayaang lumabas ang lahat ng quality
      links.sort((a, b) => score(b) - score(a));
      chosen = links[0];
      console.log("[RZ] mga link sa resulta:", links.map((a) => ({ text: a.textContent.trim().slice(0, 30), quality: qualityOf(a), score: score(a), href: (a.getAttribute("href") || "").slice(0, 80) })));
      break;
    }
    if (Date.now() - started > 25000 && res && res.textContent.trim().length > 0) {
      say("Walang download link na lumabas. Tingnan ang mensahe ng savefrom (baka private o hindi ma-download ang video)", "#b45309");
    }
  }
  if (!chosen) return say("Walang lumabas na resulta sa savefrom sa loob ng 90 segundo", "#b91c1c");

  // 4) Download
  async function fallbackClick() {
    if (fellBack) return;
    fellBack = true;
    say("Dine-download sa pamamagitan ng click");
    chosen.click();
    chrome.runtime.sendMessage({ type: "MARK_DOWNLOADED", info: i });
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === "DL_FAILED") fallbackClick();
    if (msg.type === "DL_DONE") say("✓ Tapos na ang download", "#15803d");
  });

  const url = hrefOf(chosen);
  if (!url) return fallbackClick();
  say("Nagda-download (" + qualityOf(chosen) + ")");
  let r = null;
  try { r = await chrome.runtime.sendMessage({ type: "DO_DOWNLOAD", url, info: i }); } catch (e) {}
  if (!r || !r.ok) fallbackClick();
})();
