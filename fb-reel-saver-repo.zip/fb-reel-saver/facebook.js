// Gumagana sa kahit anong Facebook page/profile. May listahan ng mga video + status kung na-download na.
const HIDE_RE = /^\/($|\?|home|marketplace|groups|friends|gaming|events|stories|messages|notifications|bookmarks|settings|login|ads|help)/i;

function toast(text) {
  let t = document.getElementById("rz-toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "rz-toast";
    t.style.cssText = "position:fixed;bottom:80px;left:20px;z-index:2147483647;background:#222;color:#fff;padding:10px 14px;border-radius:8px;font:14px sans-serif;max-width:320px;word-break:break-all";
    document.body.appendChild(t);
  }
  t.textContent = text;
  clearTimeout(t._h);
  t._h = setTimeout(() => t.remove(), 6000);
}

function videoUrlFrom(h) {
  let m = h.match(/facebook\.com\/reel\/(\d+)/);
  if (m) return "https://www.facebook.com/reel/" + m[1];
  m = h.match(/facebook\.com\/[^/]+\/videos\/(?:[^/]+\/)?(\d+)/) || h.match(/facebook\.com\/watch\/?\?(?:[^#]*&)?v=(\d+)/);
  if (m) return "https://www.facebook.com/watch/?v=" + m[1];
  return null;
}
const idOf = (u) => (u.match(/(\d+)$/) || [])[1] || "";
const currentVideoUrl = () => videoUrlFrom(location.href);

function pageName() {
  const og = document.querySelector('meta[property="og:title"]');
  const t = ((og && og.content) || document.title || "")
    .replace(/^\(\d+\+?\)\s*/, "")
    .replace(/\s*[|\-–]\s*Facebook.*$/i, "")
    .trim();
  return t || "Facebook";
}
function captionFrom(el) {
  if (!el) return "";
  const art = el.closest('[role="article"]');
  if (!art) return "";
  const pn = pageName();
  for (const d of art.querySelectorAll('div[dir="auto"], span[dir="auto"]')) {
    if (d.closest('h1,h2,h3,h4,a,[role="button"]')) continue; // pangalan ng page, link, button
    const s = d.textContent.trim();
    if (s.length > 15 && s !== pn) return s.slice(0, 120);
  }
  return "";
}

// Hanapin ang preview image ng video (best effort): <img>, background-image, o poster ng <video>
function bgUrl(x) {
  try {
    const b = getComputedStyle(x).backgroundImage || "";
    const m = b.match(/url\(["']?(https?:[^"')]+)["']?\)/);
    return m ? m[1] : "";
  } catch (err) { return ""; }
}
function collectImages(root, minW) {
  const out = [];
  root.querySelectorAll("img").forEach((i) => {
    const src = i.currentSrc || i.src || "";
    const w = i.clientWidth || i.width || 0;
    if (/^https?:/.test(src) && w >= minW) out.push({ src, area: w * (i.clientHeight || i.height || 0) });
  });
  root.querySelectorAll("*").forEach((x) => {
    const u = bgUrl(x);
    const w = x.clientWidth || 0;
    if (u && w >= minW) out.push({ src: u, area: w * (x.clientHeight || 0) });
  });
  return out;
}
const biggest = (arr) => arr.sort((a, b) => b.area - a.area)[0];

function thumbFrom(el) {
  if (!el) {
    const og = document.querySelector('meta[property="og:image"]');
    return (og && og.content) || "";
  }
  // 1) sa loob mismo ng video link
  let b = biggest(collectImages(el, 40));
  if (b) return b.src;
  // 2) sa loob ng post
  const art = el.closest('[role="article"]');
  if (art) {
    const v = art.querySelector("video[poster]");
    if (v && v.poster) return v.poster;
    b = biggest(collectImages(art, 120).filter((x) => /fbcdn|scontent/.test(x.src)));
    if (b) return b.src;
  }
  // Fallback: sumampa pataas hanggang may mahanap na larawan, hangga't iisang video lang ang laman ng container
  let p = el.parentElement;
  for (let i = 0; i < 10 && p && p !== document.body; i++, p = p.parentElement) {
    const ids = new Set();
    p.querySelectorAll("a[href]").forEach((a) => { const u = videoUrlFrom(a.href); if (u) ids.add(idOf(u)); });
    if (ids.size > 1) break;
    const b2 = biggest(collectImages(p, 120).filter((x) => /fbcdn|scontent/.test(x.src)));
    if (b2) return b2.src;
  }
  return "";
}

// Debug report para makita kung ano talaga ang istruktura ng Facebook sa page mo
function debugReport() {
  const rows = scanVideos().slice(0, 6).map((v) => {
    const chain = [];
    let p = v.el;
    for (let i = 0; p && i < 8; i++, p = p.parentElement) chain.push(p.tagName.toLowerCase() + (p.getAttribute("role") ? "[role=" + p.getAttribute("role") + "]" : ""));
    const art = v.el && v.el.closest('[role="article"]');
    return {
      id: v.id,
      url: v.url,
      caption: (v.caption || "").slice(0, 60),
      thumbFound: (v.thumb || "").slice(0, 110),
      chain: chain.join(" < "),
      hasArticle: !!art,
      meta: metaCache.get(v.id) ? { thumb: (metaCache.get(v.id).thumb || "").slice(0, 100), caption: (metaCache.get(v.id).caption || "").slice(0, 60), owner: metaCache.get(v.id).owner } : null,
      metaStatus: metaStatus[v.id] || null,
      imgsInAnchor: v.el ? collectImages(v.el, 0).map((x) => x.src.slice(0, 90) + " area=" + x.area).slice(0, 4) : [],
      imgsInArticle: art ? collectImages(art, 0).map((x) => x.src.slice(0, 90) + " area=" + x.area).slice(0, 6) : [],
    };
  });
  const txt = JSON.stringify({ page: location.pathname, count: rows.length, rows }, null, 1);
  console.log("[RZ] DEBUG", txt);
  navigator.clipboard.writeText(txt).then(
    () => toast("Na-copy ang debug report. I-paste mo sa chat."),
    () => toast("Tingnan ang Console (F12) para sa [RZ] DEBUG")
  );
}

// ---------- Meta mula sa JSON na naka-embed sa page (thumbnail + caption + pangalan ng page) ----------
// Nakita sa view-source: bawat video ay may "permalink_url", "preferred_thumbnail" at "message":{"text":...} sa JSON ng page.
const metaCache = new Map();   // id -> { thumb, caption, owner }
const metaStatus = {};         // id -> status (para sa debug)
const badThumbs = new Set();   // mga thumbnail URL na hindi nag-load
const fetchQueue = [];
let fetchCount = 0, fetching = false;
const FETCH_LIMIT = 40;        // max na bilang ng patagong pag-fetch bawat pag-load ng page

const jdec = (x) => { try { return JSON.parse('"' + x + '"'); } catch (e) { return x; } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function thumbValid(u) {
  if (!u) return false;
  const m = u.match(/[?&]oe=([0-9a-fA-F]+)/); // petsa ng pag-expire ng signed URL
  return m ? parseInt(m[1], 16) > Date.now() / 1000 + 60 : true;
}

function parseMeta(raw) {
  const u = raw.replace(/\\+\//g, "/");
  const out = {};
  const re = /"permalink_url":"https:\/\/www\.facebook\.com\/(?:reel\/|[^"\/]+\/videos\/(?:[^"\/]+\/)?)(\d+)\/?"/g;
  const marks = [];
  let m;
  while ((m = re.exec(u))) marks.push({ id: m[1], pos: m.index });
  marks.forEach((mk, i) => {
    if (out[mk.id]) return;
    const seg = u.slice(mk.pos, i + 1 < marks.length ? marks[i + 1].pos : mk.pos + 400000);
    const t = seg.match(/"preferred_thumbnail":\{"image":\{"uri":"([^"]+)"/);
    const c = seg.match(/"message":\{"text":"((?:[^"\\]|\\.)*)"/);
    const o = seg.match(/"owner":\{[^}]*?"name":"((?:[^"\\]|\\.)*)"/);
    if (t || c) out[mk.id] = { thumb: t ? jdec(t[1]) : "", caption: c ? jdec(c[1]).slice(0, 200) : "", owner: o ? jdec(o[1]).trim() : "" };
  });
  return out;
}

function mergeMeta(id, v) {
  const old = metaCache.get(id) || {};
  metaCache.set(id, { thumb: v.thumb || old.thumb || "", caption: v.caption || old.caption || "", owner: v.owner || old.owner || "" });
}

const seenScripts = new WeakSet();
function refreshDomMeta() {
  document.querySelectorAll("script").forEach((s) => {
    if (seenScripts.has(s)) return;
    seenScripts.add(s);
    const t = s.textContent;
    if (!t || t.length < 500 || t.indexOf("permalink_url") < 0) return;
    const o = parseMeta(t);
    for (const id in o) { mergeMeta(id, o[id]); if (!metaStatus[id]) metaStatus[id] = "dom"; }
  });
}

const countOf = (t, k) => t.split(k).length - 1;
function diag(text, id) {
  return text.length + " chars; id x" + countOf(text, id) + "; permalink_url x" + countOf(text, '"permalink_url"') +
    "; preferred_thumbnail x" + countOf(text, "preferred_thumbnail") + "; og:image=" + /og:image/.test(text);
}

// Kung walang "permalink_url" na katabi, kunin ang unang thumbnail/caption pagkatapos ng unang "id":"<id>"
function fallbackMeta(text, id) {
  const u = text.replace(/\\+\//g, "/");
  const start = u.indexOf('"id":"' + id + '"');
  if (start < 0) return null;
  const seg = u.slice(start, start + 400000);
  const t = seg.match(/"preferred_thumbnail":\{"image":\{"uri":"([^"]+)"/);
  const c = seg.match(/"message":\{"text":"((?:[^"\\]|\\.)*)"/);
  const o = seg.match(/"owner":\{[^}]*?"name":"((?:[^"\\]|\\.)*)"/);
  if (!t && !c) return null;
  return { thumb: t ? jdec(t[1]) : "", caption: c ? jdec(c[1]).slice(0, 200) : "", owner: o ? jdec(o[1]).trim() : "" };
}

async function fetchMeta(id) {
  const ctrl = new AbortController();
  let text = "", last = 0;
  try {
    const res = await fetch("https://www.facebook.com/reel/" + id + "/", {
      credentials: "include",
      signal: ctrl.signal,
      headers: { Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" },
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      text += dec.decode(value, { stream: true });
      if (text.length - last > 250000) {
        last = text.length;
        const m = parseMeta(text)[id];
        if (m && m.thumb && m.caption) break;
      }
      if (text.length > 3000000) break;
    }
    try { ctrl.abort(); } catch (e) {}
    const o = parseMeta(text);
    for (const k in o) mergeMeta(k, o[k]);
    if (o[id]) metaStatus[id] = "fetched";
    else {
      const fb = fallbackMeta(text, id);
      if (fb) { mergeMeta(id, fb); metaStatus[id] = "fetched (fallback)"; }
      else metaStatus[id] = "fetch: walang nahanap | " + diag(text, id);
    }
  } catch (e) {
    metaStatus[id] = "fetch error: " + (e && e.message);
  }
}

function requestMeta(id) {
  const st = metaStatus[id];
  if (st && st !== "dom" && st !== "cache") return; // nasa pila na, tapos na, o pumalya na
  metaStatus[id] = "queued";
  fetchQueue.push(id);
  runQueue();
}

async function runQueue() {
  if (fetching) return;
  fetching = true;
  while (fetchQueue.length && alive()) {
    if (panel.style.display === "none" || document.hidden) { await sleep(1500); continue; }
    if (fetchCount >= FETCH_LIMIT) { fetchQueue.splice(0).forEach((id) => (metaStatus[id] = "skipped (limit)")); break; }
    const id = fetchQueue.shift();
    fetchCount++;
    await fetchMeta(id);
    saveMeta();
    render().catch(() => {});
    await sleep(1500); // dahan-dahan para hindi magmukhang bot
  }
  fetching = false;
}

let saveTimer;
function saveMeta() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    if (!alive()) return;
    const obj = {};
    [...metaCache.entries()].slice(-150).forEach(([id, v]) => (obj[id] = v));
    try { chrome.storage.local.set({ meta: obj }); } catch (e) {}
  }, 800);
}
function loadMeta() {
  try {
    chrome.storage.local.get("meta", (d) => {
      const o = d.meta || {};
      for (const id in o) {
        const v = o[id];
        mergeMeta(id, { thumb: thumbValid(v.thumb) ? v.thumb : "", caption: v.caption, owner: v.owner });
        if (!metaStatus[id]) metaStatus[id] = "cache";
      }
    });
  } catch (e) {}
}

function applyMeta(v) {
  const m = metaCache.get(v.id);
  if (m) {
    if (m.thumb && thumbValid(m.thumb) && !badThumbs.has(m.thumb)) v.thumb = m.thumb;
    if (m.caption) v.caption = m.caption;
    if (m.owner) v.owner = m.owner;
  }
  if (v.thumb && badThumbs.has(v.thumb)) v.thumb = "";
  if (!v.thumb || !v.caption) requestMeta(v.id);
  return v;
}

// Kunin lahat ng video na nasa page ngayon (pataas-pababa, dedupe by ID)
function scanVideos() {
  refreshDomMeta();
  const map = new Map();
  const add = (u, el, fallbackCap) => {
    const id = idOf(u);
    if (!id) return;
    const cap = captionFrom(el) || fallbackCap || "";
    const th = thumbFrom(el);
    if (!map.has(id)) map.set(id, { url: u, id, caption: cap, thumb: th, el });
    else {
      const it = map.get(id);
      if (!it.caption && cap) it.caption = cap;
      if (!it.thumb && th) it.thumb = th;
    }
  };
  const cur = currentVideoUrl();
  if (cur) add(cur, null, pageName());
  for (const a of document.querySelectorAll("a[href]")) {
    const u = videoUrlFrom(a.href);
    if (u) add(u, a);
  }
  return [...map.values()].map(applyMeta);
}

// Kapag na-reload/na-update ang extension habang bukas ang tab, mawawalan ng bisa ang lumang script
let t1, t2;
function alive() { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } }
function shutdown() {
  clearInterval(t1); clearInterval(t2);
  try { btn.remove(); panel.remove(); } catch (e) {}
}

const getDownloaded = () => new Promise((r) => chrome.storage.local.get("downloaded", (d) => r(d.downloaded || {})));
const setDownloaded = (obj) => chrome.storage.local.set({ downloaded: obj });

function startDownload(v) {
  const info = { url: v.url, id: v.id, page: v.owner || pageName(), caption: v.caption, date: new Date().toISOString().slice(0, 10) };
  if (!alive()) return toast("Na-update ang extension. I-refresh ang page (F5) tapos subukan ulit.");
  toast("Idadownload: " + info.page + " • " + (info.caption || "(walang caption)") + " • ID " + info.id);
  chrome.runtime.sendMessage({ type: "OPEN_SAVEFROM", url: v.url, info });
}

// ---------- UI ----------
const G = "#16a34a";
const el = (tag, css, text) => {
  const e = document.createElement(tag);
  if (css) e.style.cssText = css;
  if (text !== undefined) e.textContent = text;
  return e;
};
const mk = (text, bg, color, fn, border) => {
  const b = el("button", "border:" + (border || "0") + ";border-radius:8px;padding:6px 11px;font:600 12px system-ui,sans-serif;cursor:pointer;color:" + color + ";background:" + bg);
  b.textContent = text;
  b.onclick = (ev) => { ev.stopPropagation(); fn(); };
  return b;
};

const btn = el("button", "position:fixed;bottom:20px;right:20px;z-index:2147483647;background:" + G + ";color:#fff;border:0;border-radius:999px;padding:12px 18px;font:700 14px system-ui,sans-serif;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.3);display:none", "📋 Mga video");

const panel = el("div", "position:fixed;bottom:72px;right:20px;z-index:2147483647;width:430px;max-width:calc(100vw - 40px);max-height:72vh;background:#f8fafc;color:#111827;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.35);font:13px system-ui,sans-serif;display:none;flex-direction:column;overflow:hidden");
const head = el("div", "padding:12px 14px 10px;background:#fff;border-bottom:1px solid #e5e7eb");
const titleRow = el("div", "display:flex;align-items:center;justify-content:space-between");
const title = el("div", "font:700 15px system-ui,sans-serif", "Mga video");
const closeBtn = el("button", "border:0;background:#f1f5f9;border-radius:999px;width:26px;height:26px;cursor:pointer;font-size:13px", "✕");
closeBtn.onclick = () => (panel.style.display = "none");
const dbgBtn = el("button", "border:0;background:#f1f5f9;border-radius:999px;width:26px;height:26px;cursor:pointer;font-size:13px;margin-right:6px", "🐞");
dbgBtn.title = "Kopyahin ang debug report";
dbgBtn.onclick = debugReport;
const rightBox = el("div", "display:flex");
rightBox.append(dbgBtn, closeBtn);
titleRow.append(title, rightBox);
const chips = el("div", "display:flex;gap:6px;margin-top:8px");
head.append(titleRow, chips);
const body = el("div", "overflow:auto;flex:1;padding:10px;display:flex;flex-direction:column;gap:10px");
panel.append(head, body);

let filter = "all";
let lastSig = "";
async function render(force) {
  if (panel.style.display === "none") return;
  const dl = await getDownloaded();
  const all = scanVideos();
  const sig = filter + "|" + all.map((i) => i.id + (dl[i.id] ? 1 : 0) + (i.thumb ? 1 : 0) + i.caption.length).join(",");
  if (sig === lastSig && !force) return;
  lastSig = sig;

  const done = all.filter((i) => dl[i.id]).length;
  const fresh = all.length - done;
  title.textContent = pageName();
  chips.textContent = "";
  for (const [key, label] of [["all", "Lahat " + all.length], ["new", "Bago " + fresh], ["done", "Na-download " + done]]) {
    const on = filter === key;
    const c = el("button", "border:1px solid " + (on ? G : "#d1d5db") + ";background:" + (on ? G : "#fff") + ";color:" + (on ? "#fff" : "#374151") + ";border-radius:999px;padding:4px 12px;font:600 12px system-ui,sans-serif;cursor:pointer", label);
    c.onclick = () => { filter = key; render(true); };
    chips.appendChild(c);
  }

  const items = all.filter((i) => (filter === "new" ? !dl[i.id] : filter === "done" ? dl[i.id] : true));
  const top = body.scrollTop;
  body.textContent = "";
  if (!items.length) {
    body.appendChild(el("div", "padding:20px;text-align:center;color:#6b7280", all.length ? "Walang video sa filter na ito." : "Wala pang nakitang video. I-scroll pababa sa page para lumabas ang mga post."));
  }
  for (const v of items) {
    const rec = dl[v.id];
    const card = el("div", "display:flex;gap:10px;background:#fff;border:1px solid " + (rec ? "#bbf7d0" : "#e5e7eb") + ";border-radius:12px;padding:8px;box-shadow:0 1px 2px rgba(0,0,0,.05)");

    // Preview
    const thumbBox = el("div", "position:relative;flex:0 0 112px;height:84px;border-radius:8px;overflow:hidden;background:#111827;cursor:pointer");
    if (v.thumb) {
      const im = el("img", "width:100%;height:100%;object-fit:cover;display:block");
      im.onerror = () => {
        console.warn("[RZ] Hindi na-load ang thumbnail:", v.id, v.thumb);
        badThumbs.add(v.thumb);
        setTimeout(() => render(true).catch(() => {}), 50);
        im.replaceWith(el("div", "color:#9ca3af;font-size:26px;display:flex;align-items:center;justify-content:center;height:100%", "🎬"));
      };
      im.src = v.thumb;
      thumbBox.appendChild(im);
    } else {
      thumbBox.appendChild(el("div", "color:#9ca3af;font-size:26px;display:flex;align-items:center;justify-content:center;height:100%", "🎬"));
    }
    thumbBox.appendChild(el("div", "position:absolute;left:6px;bottom:6px;background:rgba(0,0,0,.65);color:#fff;border-radius:4px;padding:1px 6px;font-size:11px", "▶"));
    if (rec) thumbBox.appendChild(el("div", "position:absolute;right:6px;top:6px;background:" + G + ";color:#fff;border-radius:999px;width:20px;height:20px;font-size:12px;display:flex;align-items:center;justify-content:center", "✓"));
    if (!v.thumb) console.warn("[RZ] Walang nakitang thumbnail para sa video ID", v.id);
    thumbBox.title = "I-click para hanapin sa page";
    thumbBox.onclick = () => { if (v.el && v.el.scrollIntoView) v.el.scrollIntoView({ behavior: "smooth", block: "center" }); };

    // Detalye
    const info = el("div", "flex:1;min-width:0;display:flex;flex-direction:column;gap:5px");
    info.appendChild(el("div", "font-weight:600;line-height:1.3;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden", v.caption || "(walang caption)"));
    const meta = el("div", "display:flex;align-items:center;gap:6px;font-size:11px;color:#6b7280");
    meta.appendChild(el("span", "border-radius:999px;padding:2px 8px;font-weight:700;background:" + (rec ? "#dcfce7" : "#fef3c7") + ";color:" + (rec ? "#166534" : "#92400e"), rec ? "✓ Na-download" + (rec.date ? " " + rec.date : "") : "Hindi pa"));
    meta.appendChild(el("span", "", "ID " + v.id));
    const actions = el("div", "display:flex;gap:6px;margin-top:auto");
    actions.appendChild(mk(rec ? "⬇ Ulit" : "⬇ Download", rec ? "#e5e7eb" : G, rec ? "#374151" : "#fff", () => startDownload(v)));
    actions.appendChild(
      mk(rec ? "↩ I-unmark" : "✓ Markahan", "#fff", "#2563eb", async () => {
        const cur = await getDownloaded();
        if (cur[v.id]) delete cur[v.id];
        else cur[v.id] = { page: pageName(), caption: v.caption, url: v.url, date: new Date().toISOString().slice(0, 10) };
        setDownloaded(cur);
      }, "1px solid #bfdbfe")
    );
    info.append(meta, actions);
    card.append(thumbBox, info);
    body.appendChild(card);
  }
  body.scrollTop = top;
}

btn.onclick = () => {
  const open = panel.style.display === "none";
  panel.style.display = open ? "flex" : "none";
  if (open) render(true);
};
document.body.append(btn, panel);

chrome.storage.onChanged.addListener((c) => { if (alive() && c.downloaded) render(true).catch(() => {}); });
t1 = setInterval(() => { if (!alive()) return shutdown(); render().catch(() => shutdown()); }, 2000); // sumasabay sa pag-scroll mo

// Facebook ay SPA, kaya ichecheck palagi kung nasaan na
t2 = setInterval(() => {
  if (!alive()) return shutdown();
  const show = !!currentVideoUrl() || !HIDE_RE.test(location.pathname + location.search);
  btn.style.display = show ? "block" : "none";
  if (!show) panel.style.display = "none";
}, 1000);

loadMeta();
